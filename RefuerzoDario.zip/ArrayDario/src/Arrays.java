import java.util.ArrayList;
import java.util.Scanner;

public class Arrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	
		
		
		//hacer un arribe de N numeros para ingresar numeros para calcular y sacar el promedio
		        Scanner scanner = new Scanner(System.in);
		     //  ArrayList<Double> numeros = new ArrayList<>();

		       // System.out.print("Ingrese los números (ingrese 'fin' para calcular el promedio): ");

		       // while (scanner.hasNextDouble()) {
		         //   double numero = scanner.nextDouble();
		           // numeros.add(numero);
		       // }
		        
		        //double suma = 0;
		        //for (double num : numeros) {
		          //  suma += num;
		        //}
		        
		        //double promedio = suma / numeros.size();

		        //System.out.println("El promedio de los números ingresados es: " + promedio);

		       // scanner.close();
		    //}
		
		
		        ArrayList<String> Nombre = new ArrayList<>();
		        System.out.println("Nombres que vas a añadir:");
		        
		        int cantidadNombres = scanner.nextInt();
		        
		        String[] nombres = new String[cantidadNombres];

		        
		        for (int i = 0; i < cantidadNombres; i++) {
		            System.out.println("Nombre " + (i+1) + ":");
		            nombres[i] = scanner.next();
		        }

		        
		        System.out.println("Los nombres son:");
		        for (int i = cantidadNombres - 1; i >= 0; i--) {
		            System.out.println(nombres[i]);
		        }
		    }
		}

		

	


