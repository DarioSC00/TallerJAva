import java.util.Scanner;

public class Ciclos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int numero = 0;
		
		for (int i = 1; i<=100; i++) {numero+=i;}
		System.out.println("La suma de los numeros es " + numero);
		
		
		
		Scanner scanner = new Scanner (System.in);
		String nombre;
		
		System.out.println("ingrese nombre y escriba la palabar FIN para terminar");
		System.out.println("Ingrese su nombre");
		
		nomber = scanner.next();
		
		while(nombre.equalsIgnoreCase("FIN")) {
			System.out.println("Has ingresado "+ nombre);
			
			scanner.close();
		}
		
		System.out.println("Dame un numero entero");
		numero = scanner.nextInt();
		
		if(numero > 0);{
			System.out.println("El numero es positivo");
		}
		
		else(numero<0){
			System.out.println("El numero es menor que 0 ");
		}
		
		
	}

}
